package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

	@RequestMapping("/hash")
	public String checksum() throws Exception {

		String data = "Dashayla_CS305_ProjectTwo";

		MessageDigest digest = MessageDigest.getInstance("SHA-256");

		byte[] hashBytes = digest.digest(
				data.getBytes(StandardCharsets.UTF_8));

		StringBuilder hexString = new StringBuilder();

		for (byte b : hashBytes) {
			hexString.append(String.format("%02x", b));
		}

		return "<html><body>"
				+ "<h2>Name: Dashayla</h2>"
				+ "<p>Data: " + data + "</p>"
				+ "<p>SHA-256 Checksum:</p>"
				+ "<p>" + hexString.toString() + "</p>"
				+ "</body></html>";
	}
}